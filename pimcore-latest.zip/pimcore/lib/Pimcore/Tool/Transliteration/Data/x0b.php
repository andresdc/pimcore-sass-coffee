<?php

$base = [
  0x00 => null, 'N', 'N', 'H', null, 'a', 'aa', 'i', 'ii', 'u', 'uu', 'R', 'L', null, null, 'e',
  0x10 => 'ai', null, null, 'o', 'au', 'k', 'kh', 'g', 'gh', 'ng', 'c', 'ch', 'j', 'jh', 'ny', 'tt',
  0x20 => 'tth', 'dd', 'ddh', 'nn', 't', 'th', 'd', 'dh', 'n', null, 'p', 'ph', 'b', 'bh', 'm', 'y',
  0x30 => 'r', null, 'l', 'll', null, '', 'sh', 'ss', 's', 'h', null, null, '\'', '\'', 'aa', 'i',
  0x40 => 'ii', 'u', 'uu', 'R', null, null, null, 'e', 'ai', null, null, 'o', 'au', '', null, null,
  0x50 => null, null, null, null, null, null, '+', '+', null, null, null, null, 'rr', 'rh', null, 'yy',
  0x60 => 'RR', 'LL', null, null, null, null, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  0x70 => '', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x80 => null, null, 'N', 'H', null, 'a', 'aa', 'i', 'ii', 'u', 'uu', null, null, null, 'e', 'ee',
  0x90 => 'ai', null, 'o', 'oo', 'au', 'k', null, null, null, 'ng', 'c', null, 'j', null, 'ny', 'tt',
  0xA0 => null, null, null, 'nn', 't', null, null, null, 'n', 'nnn', 'p', null, null, null, 'm', 'y',
  0xB0 => 'r', 'rr', 'l', 'll', 'lll', 'v', null, 'ss', 's', 'h', null, null, null, null, 'aa', 'i',
  0xC0 => 'ii', 'u', 'uu', null, null, null, 'e', 'ee', 'ai', null, 'o', 'oo', 'au', '', null, null,
  0xD0 => null, null, null, null, null, null, null, '+', null, null, null, null, null, null, null, null,
  0xE0 => null, null, null, null, null, null, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  0xF0 => '+10+', '+100+', '+1000+', null, null, null, null, null, null, null, null, null, null, null, null, null,
];
