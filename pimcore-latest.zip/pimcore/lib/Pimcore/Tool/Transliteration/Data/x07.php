<?php

$base = [
  0x00 => '//', '/', ',', '!', '!', '-', ',', ',', ';', '?', '~', '{', '}', '*', null, '',
  0x10 => '\'', '', 'b', 'g', 'g', 'd', 'd', 'h', 'w', 'z', 'H', 't', 't', 'y', 'yh', 'k',
  0x20 => 'l', 'm', 'n', 's', 's', '`', 'p', 'p', 'S', 'q', 'r', 'sh', 't', null, null, null,
  0x30 => 'a', 'a', 'a', 'A', 'A', 'A', 'e', 'e', 'e', 'E', 'i', 'i', 'u', 'u', 'u', 'o',
  0x40 => '', '`', '\'', '', '', 'X', 'Q', '@', '@', '|', '+', null, null, null, null, null,
  0x50 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x60 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x70 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x80 => 'h', 'sh', 'n', 'r', 'b', 'L', 'k', '\'', 'v', 'm', 'f', 'dh', 'th', 'l', 'g', 'ny',
  0x90 => 's', 'd', 'z', 't', 'y', 'p', 'j', 'ch', 'tt', 'hh', 'kh', 'th', 'z', 'sh', 's', 'd',
  0xA0 => 't', 'z', '`', 'gh', 'q', 'w', 'a', 'aa', 'i', 'ee', 'u', 'oo', 'e', 'ey', 'o', 'oa',
  0xB0 => '', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0xC0 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0xD0 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0xE0 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0xF0 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
];
