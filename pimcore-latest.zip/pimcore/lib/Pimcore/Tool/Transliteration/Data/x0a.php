<?php

$base = [
  0x00 => null, null, 'N', null, null, 'a', 'aa', 'i', 'ii', 'u', 'uu', null, null, null, null, 'ee',
  0x10 => 'ai', null, null, 'oo', 'au', 'k', 'kh', 'g', 'gh', 'ng', 'c', 'ch', 'j', 'jh', 'ny', 'tt',
  0x20 => 'tth', 'dd', 'ddh', 'nn', 't', 'th', 'd', 'dh', 'n', null, 'p', 'ph', 'b', 'bb', 'm', 'y',
  0x30 => 'r', null, 'l', 'll', null, 'v', 'sh', null, 's', 'h', null, null, '\'', null, 'aa', 'i',
  0x40 => 'ii', 'u', 'uu', null, null, null, null, 'ee', 'ai', null, null, 'oo', 'au', '', null, null,
  0x50 => null, null, null, null, null, null, null, null, null, 'khh', 'ghh', 'z', 'rr', null, 'f', null,
  0x60 => null, null, null, null, null, null, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  0x70 => 'N', 'H', '', '', 'G.E.O.', null, null, null, null, null, null, null, null, null, null, null,
  0x80 => null, 'N', 'N', 'H', null, 'a', 'aa', 'i', 'ii', 'u', 'uu', 'R', null, 'eN', null, 'e',
  0x90 => 'ai', 'oN', null, 'o', 'au', 'k', 'kh', 'g', 'gh', 'ng', 'c', 'ch', 'j', 'jh', 'ny', 'tt',
  0xA0 => 'tth', 'dd', 'ddh', 'nn', 't', 'th', 'd', 'dh', 'n', null, 'p', 'ph', 'b', 'bh', 'm', 'ya',
  0xB0 => 'r', null, 'l', 'll', null, 'v', 'sh', 'ss', 's', 'h', null, null, '\'', '\'', 'aa', 'i',
  0xC0 => 'ii', 'u', 'uu', 'R', 'RR', 'eN', null, 'e', 'ai', 'oN', null, 'o', 'au', '', null, null,
  0xD0 => 'AUM', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0xE0 => 'RR', null, null, null, null, null, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  0xF0 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
];
