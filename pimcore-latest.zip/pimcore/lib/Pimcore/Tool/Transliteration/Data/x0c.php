<?php

$base = [
  0x00 => null, 'N', 'N', 'H', null, 'a', 'aa', 'i', 'ii', 'u', 'uu', 'R', 'L', null, 'e', 'ee',
  0x10 => 'ai', null, 'o', 'oo', 'au', 'k', 'kh', 'g', 'gh', 'ng', 'c', 'ch', 'j', 'jh', 'ny', 'tt',
  0x20 => 'tth', 'dd', 'ddh', 'nn', 't', 'th', 'd', 'dh', 'n', null, 'p', 'ph', 'b', 'bh', 'm', 'y',
  0x30 => 'r', 'rr', 'l', 'll', null, 'v', 'sh', 'ss', 's', 'h', null, null, null, null, 'aa', 'i',
  0x40 => 'ii', 'u', 'uu', 'R', 'RR', null, 'e', 'ee', 'ai', null, 'o', 'oo', 'au', '', null, null,
  0x50 => null, null, null, null, null, '+', '+', null, null, null, null, null, null, null, null, null,
  0x60 => 'RR', 'LL', null, null, null, null, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  0x70 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
  0x80 => null, null, 'N', 'H', null, 'a', 'aa', 'i', 'ii', 'u', 'uu', 'R', 'L', null, 'e', 'ee',
  0x90 => 'ai', null, 'o', 'oo', 'au', 'k', 'kh', 'g', 'gh', 'ng', 'c', 'ch', 'j', 'jh', 'ny', 'tt',
  0xA0 => 'tth', 'dd', 'ddh', 'nn', 't', 'th', 'd', 'dh', 'n', null, 'p', 'ph', 'b', 'bh', 'm', 'y',
  0xB0 => 'r', 'rr', 'l', 'll', null, 'v', 'sh', 'ss', 's', 'h', null, null, null, null, 'aa', 'i',
  0xC0 => 'ii', 'u', 'uu', 'R', 'RR', null, 'e', 'ee', 'ai', null, 'o', 'oo', 'au', '', null, null,
  0xD0 => null, null, null, null, null, '+', '+', null, null, null, null, null, null, null, 'lll', null,
  0xE0 => 'RR', 'LL', null, null, null, null, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  0xF0 => null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
];
