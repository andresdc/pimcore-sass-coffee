pimcore.system_i18n = <?= \Zend_Json::encode($this->translations) ?>;
